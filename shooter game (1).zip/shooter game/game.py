from pygame import *
from random import randint

mixer.init()
mixer.music.load("space.ogg")
mixer.music.play()
fire_sound = mixer.Sound("fire.ogg")

#buat background music
img_back = "back.jpg"
img_hero = "rocket.png"
img_enemy = "ufo.png"

score =0
lost = 0

class GameSprite(sprite.Sprite):
    def __init__(self, player_image, player_x, player_y, size_x, size_y, player_speed):
        sprite.Sprite.__init__(self)
        self.image = transform.scale(image.load(player_image), (size_x,size_y))
        self.speed = player_speed
        self.rect = self.image.get_rect()
        self.rect.x = player_x
        self.rect.y = player_y
    
    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))

#kelas penerus untuk sprite pemain (dikontrol oleh panah)
class Player(GameSprite):
    def update(self):
        keys = key.get_pressed()
        if keys[K_LEFT] and self.rect.x > 5:
            self.rect.x -= self.speed
        if keys[K_RIGHT] and self.rect.x < min_width - 80:
            self.rect.x += self.speed
    def fire(self):
        pass

class Enemy(GameSprite):
    def update(self):
        self.rect.y += self.speed
        global lost
        if self.rect.y > min_height:
            self.rect.x = randint(80, min_width -80)
            self.rect.y = 0
            lost = lost+1


min_width = 700
min_height = 500
window = display.set_mode((min_width, min_height))
display.set_caption("Shooter")
background = transform.scale(image.load(img_back), (min_width, min_height))

#karakter game akan ditampilkan
pesawat = Player(img_hero, 5, min_height-100, 100,100,10)

finish = False
run = True

while run:
    for e in event.get():
        if e.type == QUIT:
            run = False
    
    if not finish:
        #perbaharui background dan pemain
        window.blit(background, (0,0))
        pesawat.update()
        pesawat.reset()
        display.update()
    time.delay(50)